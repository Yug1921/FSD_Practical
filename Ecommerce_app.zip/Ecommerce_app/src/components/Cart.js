import React, { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { Link } from "react-router-dom";

function Cart() {

  const { cart, removeFromCart } = useContext(CartContext);

  return (
    <div>

      <h2>Cart</h2>

      {cart.map(item => (

        <div key={item.id}>

          <h4>{item.title}</h4>

          <p>${item.price}</p>

          <button onClick={() => removeFromCart(item.id)}>
            Remove
          </button>

        </div>

      ))}

      <Link to="/checkout">
        <button className="btn">Go to Checkout</button>
      </Link>

    </div>
  );
}

export default Cart;